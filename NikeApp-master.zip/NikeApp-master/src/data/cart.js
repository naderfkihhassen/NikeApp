export default [
  {
    product: {
      id: "1",
      image:
        "https://notjustdev-dummy.s3.us-east-2.amazonaws.com/nike/nike1.png",
      name: "Wild Berry",
      price: 160,
    },
    size: 42,
    quantity: 2,
  },
  {
    product: {
      id: "2",
      image:
        "https://notjustdev-dummy.s3.us-east-2.amazonaws.com/nike/nike2.png",
      name: "Air Force 1",
      price: 169,
    },
    size: 43,
    quantity: 1,
  },
  {
    product: {
      id: "3",
      image:
        "https://notjustdev-dummy.s3.us-east-2.amazonaws.com/nike/nike3.png",
      name: "Nike Cosmic",
      price: 129,
    },
    size: 44,
    quantity: 1,
  },
];
